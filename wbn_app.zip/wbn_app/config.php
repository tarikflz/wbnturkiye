<?php
// Bu dosyayı config.php adıyla kopyalayıp gerçek değerleri girin.
// config.php git'e eklenmez.

return [
    'app' => [
        // 'production' ortamında hatalar ekrana basılmaz, storage/logs altına yazılır.
        'env' => 'development',
        'base_url' => 'http://localhost:8000',
        'timezone' => 'Europe/Istanbul',
    ],

    'db' => [
        'host' => 'localhost',
        'name' => 'wbn_local',
        'user' => 'wbn',
        'pass' => 'wbn_local_pw',
    ],

    // Gmail SMTP: wbnturkiye@gmail.com hesabında 2 adımlı doğrulama açık olmalı,
    // şifre olarak Google "Uygulama Şifresi" (App Password) kullanılmalı.
    'mail' => [
        // 'smtp' gerçek gönderim yapar; 'log' e-postaları storage/logs/mail.log dosyasına yazar (yerel test için).
        'transport' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'secure' => 'tls',
        'username' => 'wbnturkiye@gmail.com',
        'password' => 'cgdxkxfxpfjcpytx',
        'from_email' => 'wbnturkiye@gmail.com',
        'from_name' => 'WBN Türkiye',
        'reply_to' => 'wbnturkiye@gmail.com',
    ],

    // Form bildirimlerinin gideceği adresler.
    'notify' => [
        'default' => ['wbnturkiye@gmail.com', 'wbuzznetwork@gmail.com'],
        'receipts' => ['wbnturkiye@gmail.com', 'wbuzznetwork@gmail.com', 'tulin.cakmak@novaformdan.com'],
    ],

    'links' => [
        'tev_donation' => 'https://bagis.tev.org.tr/burs-fonu-bagisi?q=67532&k=46004',
    ],

    'uploads' => [
        'max_bytes' => 10 * 1024 * 1024,
    ],
];
